package com.example.projecttwo_ivettecerpa;

public class WeightEntry {
    private int id;
    private String date;
    private String weight;

    public WeightEntry(int id, String date, String weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;
    }

    public int getId() { return id; }
    public String getDate() { return date; }
    public String getWeight() { return weight; }

    public void setWeight(String weight) { this.weight = weight; }
}
