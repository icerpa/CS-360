package com.example.projecttwo_ivettecerpa;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

public class SMSPermissionActivity extends AppCompatActivity {

    private static final int SMS_PERMISSION_CODE = 200;
    private boolean hasPermission = false;

    private TextView tvGoalSummary;
    private Button btnRetryPermission, btnBackToLog;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sms);

        tvGoalSummary = findViewById(R.id.tvGoalSummary);
        btnRetryPermission = findViewById(R.id.btnRetryPermission);
        btnBackToLog = findViewById(R.id.btnBackToLog);

        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String goal = prefs.getString("goal_weight", null);
        if (goal != null) {
            tvGoalSummary.setText("🎯 Your Goal Weight: " + goal);
        }

        btnRetryPermission.setOnClickListener(v -> {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.SEND_SMS)) {
                // We can ask again
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.SEND_SMS},
                        SMS_PERMISSION_CODE);
            } else if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                    != PackageManager.PERMISSION_GRANTED) {
                // Permission is permanently denied
                Intent intent = new Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
                Uri uri = Uri.fromParts("package", getPackageName(), null);
                intent.setData(uri);
                startActivity(intent);
                Toast.makeText(this, "Please enable SMS permission in App Settings", Toast.LENGTH_LONG).show();
            } else {
                // Already granted
                Toast.makeText(this, "SMS permission already granted", Toast.LENGTH_SHORT).show();
            }
        });

        btnBackToLog.setOnClickListener(v -> finish());

        // First-time permission request
        requestSmsPermission();
    }

    private void requestSmsPermission() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(
                    this,
                    new String[]{Manifest.permission.SEND_SMS},
                    SMS_PERMISSION_CODE
            );
        } else {
            hasPermission = true;
            promptPhoneNumber();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions,
                                           int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);

        if (requestCode == SMS_PERMISSION_CODE) {
            hasPermission = grantResults.length > 0 &&
                    grantResults[0] == PackageManager.PERMISSION_GRANTED;

            if (hasPermission) {
                Toast.makeText(this, "SMS permission granted", Toast.LENGTH_SHORT).show();
                promptPhoneNumber();
            } else {
                Toast.makeText(this, "SMS alerts disabled — goal tracking still works!", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void promptPhoneNumber() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Enter Your Phone Number");

        final EditText input = new EditText(this);
        input.setHint("e.g. 5551234567");
        builder.setView(input);

        builder.setPositiveButton("Continue", (dialog, which) -> {
            String number = input.getText().toString().trim();
            if (!number.isEmpty()) {
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
                prefs.edit().putString("user_phone", number).apply();
                promptGoalWeight();
            } else {
                Toast.makeText(this, "Phone number is required", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", null);
        builder.show();
    }

    private void promptGoalWeight() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Set Goal Weight");

        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 30, 50, 10);

        final EditText input = new EditText(this);
        input.setHint("e.g. 70kg");
        layout.addView(input);

        if (!hasPermission) {
            TextView warning = new TextView(this);
            warning.setText("SMS alerts are disabled — you'll still see progress in the app.");
            warning.setTextColor(ContextCompat.getColor(this, android.R.color.darker_gray));
            warning.setPadding(0, 20, 0, 0);
            layout.addView(warning);
        }

        builder.setView(layout);

        builder.setPositiveButton("Save", (dialog, which) -> {
            String goal = input.getText().toString().trim();
            if (!goal.isEmpty()) {
                SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
                prefs.edit().putString("goal_weight", goal).apply();
                Toast.makeText(this, "Goal Weight Saved", Toast.LENGTH_SHORT).show();
                finish();
            } else {
                Toast.makeText(this, "Goal weight cannot be empty", Toast.LENGTH_SHORT).show();
            }
        });

        builder.setNegativeButton("Cancel", (dialog, which) -> finish());
        builder.show();
    }
}
