package com.example.projecttwo_ivettecerpa;

import android.Manifest;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.telephony.SmsManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class MainActivity extends AppCompatActivity {

    DatabaseHelper dbHelper;
    List<WeightEntry> weightList = new ArrayList<>();
    WeightEntryAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        dbHelper = new DatabaseHelper(this);

        EditText etDate = findViewById(R.id.etDate);
        EditText etWeight = findViewById(R.id.etWeight);
        Button btnAdd = findViewById(R.id.btnAddWeight);
        Button btnSetGoal = findViewById(R.id.btnSetGoal);
        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        adapter = new WeightEntryAdapter(weightList, dbHelper);
        recyclerView.setAdapter(adapter);

        btnAdd.setOnClickListener(v -> {
            String date = etDate.getText().toString().trim();
            String weightStr = etWeight.getText().toString().trim();

            if (date.isEmpty() || weightStr.isEmpty()) {
                Toast.makeText(this, "Please enter date and weight", Toast.LENGTH_SHORT).show();
                return;
            }

            if (dbHelper.insertWeight(date, weightStr)) {
                checkGoalAndSendSMS(weightStr);
                loadWeights();
                adapter.notifyDataSetChanged();
                etDate.setText("");
                etWeight.setText("");
            }
        });

        btnSetGoal.setOnClickListener(v -> {
            Intent intent = new Intent(this, SMSPermissionActivity.class);
            startActivity(intent);
        });

        loadWeights();
    }

    private void loadWeights() {
        weightList.clear();
        Cursor cursor = dbHelper.getAllWeights();
        while (cursor.moveToNext()) {
            int id = cursor.getInt(0);
            String date = cursor.getString(1);
            String weight = cursor.getString(2);
            weightList.add(new WeightEntry(id, date, weight));
        }
    }

    private void checkGoalAndSendSMS(String currentWeightStr) {
        SharedPreferences prefs = PreferenceManager.getDefaultSharedPreferences(this);
        String goalStr = prefs.getString("goal_weight", null);
        String phone = prefs.getString("user_phone", null);

        if (goalStr != null) {
            try {
                float currentWeight = Float.parseFloat(currentWeightStr.replaceAll("[^\\d.]", ""));
                float goalWeight = Float.parseFloat(goalStr.replaceAll("[^\\d.]", ""));

                if (currentWeight <= goalWeight) {
                    if (phone != null && !phone.isEmpty()
                            && ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS)
                            == PackageManager.PERMISSION_GRANTED) {

                        String message = "🎉 Congratulations! You reached your goal weight of " + goalStr + "!";
                        SmsManager.getDefault().sendTextMessage(phone, null, message, null, null);
                        Toast.makeText(this, "Goal reached! SMS sent.", Toast.LENGTH_SHORT).show();
                    } else {
                        Toast.makeText(this, "🎉 Goal reached! Great job!", Toast.LENGTH_LONG).show();
                    }
                }

            } catch (NumberFormatException e) {
                Toast.makeText(this, "Could not compare weights", Toast.LENGTH_SHORT).show();
            }
        }
    }
}
