package com.example.projecttwo_ivettecerpa;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;


public class WeightEntryAdapter extends RecyclerView.Adapter<WeightEntryAdapter.ViewHolder> {
    private List<WeightEntry> weightEntries;
    private DatabaseHelper dbHelper;


    public WeightEntryAdapter(List<WeightEntry> weightList, DatabaseHelper dbHelper) {
        this.weightEntries = weightList;
        this.dbHelper = dbHelper;
    }



    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_weight_entry, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        WeightEntry entry = weightEntries.get(position);
        holder.tvDate.setText(entry.getDate());
        holder.tvWeight.setText(entry.getWeight());

        // Delete action
        holder.btnDelete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                int adapterPosition = holder.getAdapterPosition();
                int id = entry.getId();
                if (dbHelper.deleteWeight(id)) {
                    weightEntries.remove(adapterPosition);
                    notifyItemRemoved(adapterPosition);
                }
            }
        });

        // Edit action
        holder.btnEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                final EditText input = new EditText(holder.itemView.getContext());
                input.setHint("New Weight (e.g. 74kg)");

                new AlertDialog.Builder(holder.itemView.getContext())
                        .setTitle("Edit Weight")
                        .setView(input)
                        .setPositiveButton("Update", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                String newWeight = input.getText().toString();
                                if (dbHelper.updateWeight(entry.getId(), newWeight)) {
                                    entry.setWeight(newWeight);
                                    notifyItemChanged(holder.getAdapterPosition());
                                }
                            }
                        })
                        .setNegativeButton("Cancel", null)
                        .show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return weightEntries.size();
    }

    public static class ViewHolder extends RecyclerView.ViewHolder {
        TextView tvDate, tvWeight;
        Button btnDelete, btnEdit;

        public ViewHolder(View itemView) {
            super(itemView);
            tvDate = itemView.findViewById(R.id.tvDate);
            tvWeight = itemView.findViewById(R.id.tvWeight);
            btnDelete = itemView.findViewById(R.id.btnDelete);
            btnEdit = itemView.findViewById(R.id.btnEdit);
        }
    }
}
